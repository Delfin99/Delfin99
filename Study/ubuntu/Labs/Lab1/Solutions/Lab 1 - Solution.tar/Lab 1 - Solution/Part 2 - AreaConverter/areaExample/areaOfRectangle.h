#ifndef AREAOFRECTANGLE_H_
#define AREAOFRECTANGLE_H_

int areaOfRectangle(int length, int bredth);

#endif //  AREAOFRECTANGLE_H_
