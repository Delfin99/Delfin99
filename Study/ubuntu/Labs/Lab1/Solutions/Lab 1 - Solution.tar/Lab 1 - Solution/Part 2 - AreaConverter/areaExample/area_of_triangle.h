#ifndef AREAOFTRIANGLE_H_
#define AREAOFTRIANGLE_H_

area_of_triangle( double a, double b, double c );

#endif //  AREAOFTRIANGLE_H_
