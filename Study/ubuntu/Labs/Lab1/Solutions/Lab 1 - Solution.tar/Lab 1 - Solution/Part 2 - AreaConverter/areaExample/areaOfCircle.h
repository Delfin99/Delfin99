#ifndef AREAOFCIRCLE_H_
#define AREAOFCIRCLE_H_

int areaOfCircle(int length);

#endif //  AREAOFCIRCLE_H_
