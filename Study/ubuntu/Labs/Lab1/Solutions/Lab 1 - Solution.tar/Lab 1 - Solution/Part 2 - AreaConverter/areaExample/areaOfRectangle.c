int areaOfRectangle(int length, int bredth) { 
   int area;
   
   area = length * bredth;
   
   return area;
}
